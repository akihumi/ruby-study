<?php
class Event extends AppModel {
//	public $hasMany = array('Post');
	public $validate = array(
		'title' => array(
			'rule' => array('maxLength', 60),
			'required' => true,
			'allowEmpty' => false,
			'message' => 'タイトルを入力してください!'
		),
		'body' => array(
			'rule' => array('minLength', 0),
			'required' => true,
			'allowEmpty' => false,
			'message' => '詳細を入力してください!!'
		),
		'group_id' => array(
			'rule' => array('multiple', array('min' => 1)),
			'message' =>'少なくとも一つのグループを選択してください'
//			'required' => true,
		)
	);
}