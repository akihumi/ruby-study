<?php
class Post extends AppModel {
	public $belongsTo = array('Group', 'Event');
}