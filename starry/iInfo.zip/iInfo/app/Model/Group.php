<?php
class Group extends AppModel {
}