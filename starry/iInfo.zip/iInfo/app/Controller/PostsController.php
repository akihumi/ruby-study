<?php

class PostsController extends AppController {

	public function index() {
		$options = array('order' => 'Post.event_id');
		$source = $this->Post->find('all', $options);
		$event = $data = $group = array();
		$prev = 0;
		foreach ($source as $value) {
			if(!((int) $value['Event']['id'] == $prev)){
				$group = array();
			}
			array_push($group, $value['Group']['name']);
			$event['Event'] = $value['Event'];
			$event['Group']  = $group;
			$data[$value['Event']['id']] = $event;

			$prev = $value['Event']['id'];
		}

		//debug($data);
		$this->set('data', $data);
		$this->render('index');
	}

	public function create() {
		$this->set('groups', $this->Post->Group->find('list'));
		$list = Set::Combine($this->Post->Group->find('all'), '{n}.Group.id', '{n}.Group.name');
		$this->set(compact('list'));
		/* データがpostされると起動 */
		if($this->request->is('post')){
			$e_data = array(
				'title' => $this->request->data['Event']['title'], 
				'body' => $this->request->data['Event']['body'],
				'date' => $this->request->data['Event']['date']
			);
			debug($this->request->data);
			$id = $this->Post->Event->save($e_data);
			// 追加に失敗すると画面はそのまま
			if($id === false){
				$this->render('create');
				return;
			}
			// Postsテーブルに追加
			$post_group = $this->request->data['Event']['group_id'];
			if($post_group == ""){
				$error_msg = '少なくとも一つのグループに投稿してください';
				$this->set('error_msg', $error_msg);
				debug($error_msg);
				$this->render('create');
				return;
			}
			foreach($post_group as $group){
				$p_data = array(
					'event_id' => $id['Event']['id'],
					'group_id' => $group
				);
				$this->Post->save($p_data);
				$this->Post->create();
				debug($p_data);
			}

			// 投稿に成功したら前画面へ戻る
			$this->Session->setFlash("投稿しました!");
			$this->redirect('/Posts/index');
			return;
		}
		$this->render('create');
	}
}